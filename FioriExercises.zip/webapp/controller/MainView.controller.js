sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast"
],
function (Controller, MessageToast) {
    "use strict";

    return Controller.extend("com.training.day3exer1abestano.controller.MainView", {
        onInit: function () {

        },
        
        onAddItem: function (){
            var oTextBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            var sMsg = oTextBundle.getText("addButtonMsg");
            this.fnDisplayMsg(sMsg);
        },

        fnDisplayMsg: function (sMsg){
            MessageToast.show(sMsg);
        },

        onChangeMOP: function (oEvent) {
            var sSelectedKey = oEvent.getParameter("selectedItem").getProperty("key");
            var sSelectedText = oEvent.getParameter("selectedItem").getText();
            var oMobileLabel = this.getView().byId("idLblPhone");
            var oMobileInput = this.getView().byId("idInputPhone");
            var oCCDetailsLabel = this.getView().byId("idLblCCDetails");
            var oCCDetailsInput = this.getView().byId("idInputCCDetails");

            if (sSelectedKey === "GCASH"){
                 oMobileLabel.setVisible(true); 
                 oMobileInput.setVisible(true); 
                 oCCDetailsLabel.setVisible(false); 
                 oCCDetailsInput.setVisible(false); 
            } else if (sSelectedKey === "CC") {
                 oMobileLabel.setVisible(false); 
                 oMobileInput.setVisible(false); 
                 oCCDetailsLabel.setVisible(true); 
                 oCCDetailsInput.setVisible(true); 
            } else { 
                oMobileLabel.setVisible(false); 
                oMobileInput.setVisible(false); 
                oCCDetailsLabel.setVisible(false); 
                oCCDetailsInput.setVisible(false); 
            }
            MessageToast.show(sSelectedText);
        },

        onPressCheckout: function (){
            var oTextBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle(); 
            var oInputFNameValue = this.getView().byId("idInptFName").getValue(); 
            var oInputLNameValue = this.getView().byId("idInptLName").getValue(); 
            if (oInputFNameValue === "" && oInputLNameValue === ""){
                 var sMsg = oTextBundle.getText("requiredFieldBlank"); 
                 MessageToast.show(sMsg); 
            } 
        }

    });
});
