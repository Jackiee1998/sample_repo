sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.training.day3exer1abestano.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  