sap.ui.define([
	"comtraining/day3exer1_abestano/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});
