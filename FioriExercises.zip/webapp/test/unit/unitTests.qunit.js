/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"comtraining/day3exer1_abestano/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});
