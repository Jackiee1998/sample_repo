/* global QUnit */

sap.ui.require(["com/training/day3exer1abestano/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
